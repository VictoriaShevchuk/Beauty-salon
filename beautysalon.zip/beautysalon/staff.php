<footer>
<div class="row">
<div class="col-12"> 
<div class="foot">                   
<a class="envelope" href="#"><i class="fa fa-envelope"></i>beautysalon@yandex.ru</a><br>
<p></p>
<div class="text">
Copyright <?php echo '&copy2023'; ?>
</div>
</div>
</div>
</div>
</div>
</footer>
</body>
</html>
