<header>
<div class="row">
<div class="col-lg-4">  
</div>

<div class="col-lg-4">  
<h3 class="salon">Салон красоты <br>Bellezza</h3>
</div>

<div class="col-4">  
</div>


<div class="col-lg-12">  
<nav class="navbar navbar-expand-lg">
                <div class="container-fluid justify-content-center ">
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Переключатель навигации">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse flex-grow-0" id="navbarNav">
                    <div class="menu">
                    <ul class="navbar-nav ">
                      <li class="nav-item">
                        <a class="nav-link active" href="#index">Главная</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" href="#services">Услуги</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" href="#staff">Сотрудники</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" href="#aboutus">О нас</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" href="#contacts">Контакты</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </nav>
            </div>
</div>
</div>
</header> 