<?php 
include 'template/head.php'; 
include 'template/nav.php'; 
include 'template/data.php';
?>

<?php 
include 'template/footer.php'; 
?>